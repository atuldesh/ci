<?php

namespace App\Controllers;

use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;
use App\Models\FeesModel;
use App\Models\RepoModel;
use App\Models\ReceiptListModel;

class FeesData extends BaseController
{

}
?>